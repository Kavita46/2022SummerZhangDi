module.exports = {
    devServer: {
        host: '127.0.0.1',
    },
    // 打包后的项目
    publicPath: './'
}
