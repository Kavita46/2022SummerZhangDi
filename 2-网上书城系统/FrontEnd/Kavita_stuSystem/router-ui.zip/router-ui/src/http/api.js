import users from './modules/users.js'
import books from './modules/books.js'
import orders from './modules/orders.js'
export default {
    users,
    books,
    orders
}