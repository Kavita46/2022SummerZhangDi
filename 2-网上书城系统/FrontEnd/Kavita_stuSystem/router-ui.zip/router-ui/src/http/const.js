

export default {
    USERS: 'users',
   BOOKS:'books',
   ORDERS:'orders'

}


export const USERS = 'users';
export const BOOKS = 'books'
export const ORDERS = 'orders'
